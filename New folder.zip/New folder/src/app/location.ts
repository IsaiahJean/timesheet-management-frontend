export interface ILocation{
        id: number;
        sector: string;
        location: string;

}