export interface IDoctor{
        id: number;
        first_Name: string;
        last_Name: string;
        pay_roll: string;

}