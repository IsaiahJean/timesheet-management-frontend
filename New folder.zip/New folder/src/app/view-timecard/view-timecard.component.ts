import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-view-timecard',
  templateUrl: './view-timecard.component.html',
  styleUrls: ['./view-timecard.component.css']
})
export class ViewTimecardComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
