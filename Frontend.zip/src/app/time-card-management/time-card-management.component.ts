import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-time-card-management',
  templateUrl: './time-card-management.component.html',
  styleUrls: ['./time-card-management.component.css']
})
export class TimeCardManagementComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
