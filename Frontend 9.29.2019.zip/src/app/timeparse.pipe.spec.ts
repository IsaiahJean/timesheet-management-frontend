import { TimeparsePipe } from './timeparse.pipe';

describe('TimeparsePipe', () => {
  it('create an instance', () => {
    const pipe = new TimeparsePipe();
    expect(pipe).toBeTruthy();
  });
});
