export interface IDoctor{
    filter:any;
        first_Name: string;
        last_Name: string;
        pay_roll: string;

}