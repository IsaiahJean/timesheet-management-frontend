export interface ILocation{
    filter:any;
        sector: string;
        location: string;

}